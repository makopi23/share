package chap01.sec06;

import io.reactivex.Completable;
import io.reactivex.CompletableObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

/** リスト32：Completableのサンプル */
public class L32_CompletableSample {
  
  public static void main(String[] args) throws Exception {
    // Completableの作成
    Completable completable = Completable.create(emitter -> {
      // …略 何らかの処理を行う
      
      // 完了を通知する
      emitter.onComplete();
    });
    
    completable
        // Completableを非同期で行う
        .subscribeOn(Schedulers.computation())
        // 購読する
        .subscribe(new CompletableObserver() {
          
          /** 購読の準備ができた際の処理を行う */
          @Override
          public void onSubscribe(Disposable disposable) {
            // 何もしない
          }
          
          /** 完了の通知を受け取った際の処理を行う */
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
          
          /** エラーの通知を受け取った際の処理を行う */
          @Override
          public void onError(Throwable e) {
            System.out.println("エラー=" + e);
          }
        });
    
    // しばらく待つ
    Thread.sleep(100L);
  }
  
}
