package chap04.sec02;

import java.util.List;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** toList()のサンプル */
public class ToListSample {
  
  public static void main(String[] args) {
    
    Single<List<String>> single =
        // Flowableの生成
        Flowable.just("A", "B", "C", "D", "E")
            // 全データを持つListを通知
            .toList();
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
  }
}
