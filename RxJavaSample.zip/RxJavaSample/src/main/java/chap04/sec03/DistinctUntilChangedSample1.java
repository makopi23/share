package chap04.sec03;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** distinctUntilChanged()のサンプル */
public class DistinctUntilChangedSample1 {
  
  public static void main(String[] args) {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.just("A", "a", "a", "A", "a")
            // 連続して重複したデータを除いて通知する
            .distinctUntilChanged();
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
  }
}
