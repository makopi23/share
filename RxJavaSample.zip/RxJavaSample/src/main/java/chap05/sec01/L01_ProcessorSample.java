package chap05.sec01;

import org.reactivestreams.Processor;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.processors.PublishProcessor;

/** リスト1：Processorがデータを受け取りそれを通知する例 */
public class L01_ProcessorSample {
  
  public static void main(String[] args) {
    // Processorの生成
    Processor<Integer, Integer> processor = PublishProcessor.create();
    
    // Processorを購読する
    processor.subscribe(new Subscriber<Integer>() {
      
      @Override
      public void onSubscribe(Subscription subscription) {
        subscription.request(Long.MAX_VALUE);
      }
      
      @Override
      public void onNext(Integer data) {
        System.out.println(data);
      }
      
      @Override
      public void onError(Throwable error) {
        System.err.println("エラー: " + error);
      }
      
      @Override
      public void onComplete() {
        System.out.println("完了");
      }
    });
    
    // Processorにデータを渡す
    processor.onNext(1);
    processor.onNext(2);
    processor.onNext(3);
  }
  
}
