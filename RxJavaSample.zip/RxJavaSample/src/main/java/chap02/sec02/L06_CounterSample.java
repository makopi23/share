package chap02.sec02;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** リスト6：2つのスレッドからアクセスし処理を行う場合 */
public class L06_CounterSample {
  
  public static void main(String[] args) throws Exception {
    // カウントするオブジェクト
    final Counter counter = new Counter();
    // 10,000回カウントする非同期のタスクを作成
    Runnable task = () -> {
      for (int i = 0; i < 10000; i++) {
        counter.increment();
      }
    };
    
    // 非同期タスクの生成の準備
    ExecutorService executorService = Executors.newCachedThreadPool();
    
    // 新しいスレッドで開始
    Future<Boolean> future1 = executorService.submit(task, true);
    // 新しいスレッドで開始
    Future<Boolean> future2 = executorService.submit(task, true);
    
    // 結果が返ってくるまで待つ
    if (future1.get() && future2.get()) {
      // 結果を標準出力
      System.out.println(counter.get());
    } else {
      System.err.println("失敗しました");
    }
    
    // 非同期タスクをシャットダウンする
    executorService.shutdown();
  }
  
  /** スレッドセーフでない順にカウントするクラス */
  private static class Counter {
    private volatile int count;
    
    void increment() {
      count++;
    }
    
    int get() {
      return count;
    }
  }
  
}
