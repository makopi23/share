package chap04.sec05;

import java.util.concurrent.TimeUnit;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** isEmpty()のサンプル */
public class IsEmptySample {
  
  public static void main(String[] args) throws Exception {
    Single<Boolean> single =
        // Flowableの生成
        Flowable.interval(1000L, TimeUnit.MILLISECONDS)
            // 3件まで
            .take(3)
            // 3以上のみ通知
            .filter(data -> data >= 3)
            // 空かどうかを判定
            .isEmpty();
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
