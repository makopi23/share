package chap04.sec01;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** error(throwable)のサンプル */
public class ErrorSample<T> {
  
  public static void main(String[] args) {
    
    Flowable
        // エラーを通知するFlowableの生成
        .error(new Exception("例外発生"))
        // 購読開始
        .subscribe(new DebugSubscriber<>());
  }
  
}
