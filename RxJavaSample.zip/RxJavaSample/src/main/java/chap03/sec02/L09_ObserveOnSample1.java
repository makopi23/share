package chap03.sec02;

import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subscribers.ResourceSubscriber;

/** リスト9：observeOnメソッドでbufferSizeを指定している場合（bufferSize=1） */
public class L09_ObserveOnSample1 {
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // 300ミリ秒ごとに0から始まるデータを通知するFlowableを生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // BackpressureMode.DROPを設定した時と同じ挙動にする
            .onBackpressureDrop();
    flowable
        // 非同期でデータを受け取るようにし、バッファサイズを1にする
        .observeOn(Schedulers.computation(), false, 1)
        // 購読する
        .subscribe(new ResourceSubscriber<Long>() {
          // データを受け取った際の処理
          @Override
          public void onNext(Long item) {
            // 重い処理をしていると見なし1000ミリ秒待つ
            try {
              Thread.sleep(1000L);
            } catch (InterruptedException e) {
              e.printStackTrace();
              // 異常終了で終わる
              System.exit(1);
            }
            // 実行しているThread名の取得
            String threadName = Thread.currentThread().getName();
            // 受け取ったデータを出力する
            System.out.println(threadName + ": " + item);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
          
          @Override
          public void onError(Throwable error) {
            System.out.println("エラー=" + error);
          }
        });
    
    // しばらく待つ
    Thread.sleep(7000L);
  }
}
