package chap03.sec03;

import io.reactivex.Flowable;
import io.reactivex.subscribers.DisposableSubscriber;

/** リスト17：エラー時に代替データを通知する場合 */
public class L17_OnErrorResumeItemSample {
  
  public static void main(String[] args) {
    Flowable.just(1, 3, 5, 0, 2, 4)
        // 受け取ったデータで100を割る
        .map(data -> 100 / data)
        // エラーが発生したら「0」を通知する
        .onErrorReturnItem(0)
        // 購読する
        .subscribe(new DisposableSubscriber<Integer>() {
          
          @Override
          public void onNext(Integer data) {
            System.out.println("data=" + data);
          }
          
          @Override
          public void onError(Throwable error) {
            System.out.println("error=" + error);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
        });
  }
}
