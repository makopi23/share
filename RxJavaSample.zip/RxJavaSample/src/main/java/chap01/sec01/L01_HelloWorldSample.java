package chap01.sec01;

import io.reactivex.Flowable;

/** リスト1："Hello"と"World"を出力するサンプル */
public class L01_HelloWorldSample {
  
  public static void main(String[] args) {
    // データを通知する生産者の作成
    Flowable<String> flowable = Flowable.just("Hello", "World!");
    // 受け取った通知データを出力する
    flowable.subscribe(data -> System.out.println(data));
  }
  
}
