package chap04.sec07;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** repeatUntil(stop)のサンプル */
public class RepeatUntilSample {
  
  public static void main(String[] args) throws Exception {
    // 処理の開始時間
    final long startTime = System.currentTimeMillis();
    
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(100L, TimeUnit.MILLISECONDS)
            // 3件まで
            .take(3)
            // 通知を繰り返す
            .repeatUntil(() -> {
              // 呼ばれた際に出力
              System.out.println("called");
              // 処理の開始から500ミリ秒を超すまで繰り返す
              return System.currentTimeMillis() - startTime > 500L;
            });
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(1000L);
  }
}
