package chap06.sec03;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import io.reactivex.Flowable;
import io.reactivex.subscribers.DisposableSubscriber;

/** blockingSubscribe(subscriber)のサンプル */
public class BlockingSubscribeTest {
  
  @Test
  public void Flowableを実行し処理結果を確認する() {
    Flowable<Long> flowable =
        // Flowableを生成
        Flowable.interval(100L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5);
    
    // カウントするオブジェクト
    Counter counter = new Counter();
    
    // 副作用を発生させる処理を行う
    flowable
        // 現在のスレッドで購読する
        .blockingSubscribe(new DisposableSubscriber<Long>() {
          
          @Override
          public void onNext(Long data) {
            counter.increment();
          }
          
          @Override
          public void onError(Throwable error) {
            fail(error.getMessage());
          }
          
          @Override
          public void onComplete() {
            // 何もしない
          }
        });
    
    // Counterの値を確認
    assertThat(counter.get(), is(5));
  }
  
  /** 順にカウントするクラス */
  private static class Counter {
    private volatile int count;
    
    void increment() {
      count++;
    }
    
    int get() {
      return count;
    }
  }
}
