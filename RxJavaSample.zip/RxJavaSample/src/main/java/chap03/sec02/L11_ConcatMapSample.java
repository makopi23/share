package chap03.sec02;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;

/** リスト11：concatMapメソッド内で異なるスレッド上で動くFlowableを生成した場合 */
public class L11_ConcatMapSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.just("A", "B", "C")
            // 受け取ったデータからFlowableを生成し、それが持つデータを通知する
            .concatMap(data -> {
              // 1000ミリ秒遅れてデータを通知するFlowableを生成
              return Flowable.just(data).delay(1000L, TimeUnit.MILLISECONDS);
            });
    
    // 購読する
    flowable.subscribe(data -> {
      String threadName = Thread.currentThread().getName();
      String time =
          LocalTime.now().format(DateTimeFormatter.ofPattern("ss.SSS"));
      System.out.println(threadName + ": data=" + data + ", time=" + time);
    });
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
}
