package chap04.sec04;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** concatEager(sources)のサンプル */
public class ConcatEagerSample {
  
  public static void main(String[] args) throws Exception {
    // 結合対象
    Flowable<Long> flowable1 =
        // 300ミリ秒ごとにデータを通知する
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5);
    
    // 結合対象
    Flowable<Long> flowable2 =
        // 500ミリ秒ごとにデータを通知する
        Flowable.interval(500L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5)
            // 100加算する
            .map(data -> data + 100L);
    
    // 複数のFlowableを結合する
    List<Flowable<Long>> sources = Arrays.asList(flowable1, flowable2);
    Flowable<Long> result = Flowable.concatEager(sources);
    
    // 購読する
    result.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
  
}
