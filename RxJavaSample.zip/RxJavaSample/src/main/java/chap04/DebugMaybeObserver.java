package chap04;

import io.reactivex.observers.DisposableMaybeObserver;

/** デバッグ用のMaybeObserver */
public class DebugMaybeObserver<T> extends DisposableMaybeObserver<T> {
  
  private String label;
  
  public DebugMaybeObserver() {
    super();
  }
  
  public DebugMaybeObserver(String label) {
    super();
    this.label = label;
  }
  
  @Override
  public void onSuccess(T data) {
    String threadName = Thread.currentThread().getName();
    if (label == null) {
      System.out.println(threadName + ": " + data);
    } else {
      System.out.println(threadName + ": " + label + ": " + data);
    }
  };
  
  @Override
  public void onError(Throwable throwable) {
    // onErrorメソッドの呼び出し時に出力
    String threadName = Thread.currentThread().getName();
    if (label == null) {
      System.out.println(threadName + ": エラー = " + throwable);
    } else {
      System.out.println(threadName + ": " + label + ": エラー = " + throwable);
    }
  }
  
  @Override
  public void onComplete() {
    String threadName = Thread.currentThread().getName();
    if (label == null) {
      System.out.println(threadName + ": 完了");
    } else {
      System.out.println(threadName + ": " + label + ": 完了");
    }
  }
}
