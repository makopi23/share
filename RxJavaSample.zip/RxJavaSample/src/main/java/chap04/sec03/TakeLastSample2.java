package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** takeLast(count, time, unit)のサンプル */
public class TakeLastSample2 {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 10件まで
            .take(10)
            // 最後の1000ミリ秒間に通知されたデータのうち最後の2件を通知する
            .takeLast(2, 1000L, TimeUnit.MILLISECONDS);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
