package chap04.sec04;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** merge(source1, source2)のサンプル */
public class MergeSample {
  
  public static void main(String[] args) throws Exception {
    // マージ対象
    Flowable<Long> flowable1 =
        // 300ミリ秒ごとにデータを通知する
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5);
    
    // マージ対象
    Flowable<Long> flowable2 =
        // 500ミリ秒ごとにデータを通知する
        Flowable.interval(500L, TimeUnit.MILLISECONDS)
            // 2件まで
            .take(2)
            // 100加算する
            .map(data -> data + 100L);
    
    // 複数のFlowableをマージする
    Flowable<Long> result = Flowable.merge(flowable1, flowable2);
    
    // 購読する
    result.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
  
}
