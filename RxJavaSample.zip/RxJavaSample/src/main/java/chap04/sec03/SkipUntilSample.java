package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** skipUntil(other)のサンプル */
public class SkipUntilSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 引数のFlowableが通知するまでデータを通知しない
            .skipUntil(Flowable.timer(1000L, TimeUnit.MILLISECONDS));
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
  
}
