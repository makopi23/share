package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;

/** throttleWithTimeout(time, unit)のサンプル */
public class ThrottleWithTimeoutSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.<String> create(
            // 通知処理
            emitter -> {
              // データを通知し、しばらく待つ
              emitter.onNext("A");
              Thread.sleep(1000L);
              
              emitter.onNext("B");
              Thread.sleep(300L);
              
              emitter.onNext("C");
              Thread.sleep(300L);
              
              emitter.onNext("D");
              Thread.sleep(1000L);
              
              emitter.onNext("E");
              Thread.sleep(100L);
              
              // 完了を通知
              emitter.onComplete();
            }, BackpressureStrategy.BUFFER)
            // 指定した期間に次のデータが来なければ通知する
            .throttleWithTimeout(500L, TimeUnit.MILLISECONDS);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
  }
}
