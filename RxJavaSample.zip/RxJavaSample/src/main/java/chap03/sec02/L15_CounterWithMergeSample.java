package chap03.sec02;

import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;

/** リスト15：mergeメソッドを使って結合した場合 */
public class L15_CounterWithMergeSample {
  
  public static void main(String[] args) throws Exception {
    // カウントするオブジェクト
    final Counter counter = new Counter();
    
    // 10,000回Counterのincrementメソッドを呼ぶ
    Flowable<Integer> source1 = Flowable.range(1, 10000)
        // Flowableを異なるスレッド上で処理を行うようにする
        .subscribeOn(Schedulers.computation())
        // 異なるスレッド上で処理を行うようにする
        .observeOn(Schedulers.computation());
    
    // 別のスレッドで同時に実行する
    Flowable<Integer> source2 = Flowable.range(1, 10000)
        // Flowableを異なるスレッド上で処理を行うようにする
        .subscribeOn(Schedulers.computation())
        // 異なるスレッド上で処理を行うようにする
        .observeOn(Schedulers.computation());
    
    // 2つのFlowableをマージする
    Flowable.merge(source1, source2)
        // 購読する
        .subscribe(
            // データを受け取った際の処理
            data -> counter.increment(),
            // エラーを受け取った際の処理
            error -> System.out.println("エラー=" + error),
            // 完了の通知を受け取った際の処理
            () -> System.out.println("counter.get()=" + counter.get()));
    
    // しばらく待つ
    Thread.sleep(1000L);
  }
}
