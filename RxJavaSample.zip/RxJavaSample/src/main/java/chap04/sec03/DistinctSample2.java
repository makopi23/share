package chap04.sec03;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** distinct(keySelector)のサンプル */
public class DistinctSample2 {
  
  public static void main(String[] args) {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.just("A", "a", "B", "b", "A", "a", "B", "b")
            // 大文字・小文字に関係なく重複したデータを除いて通知する
            .distinct(data -> data.toLowerCase());
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
  }
}
