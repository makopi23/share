package chap04.sec02;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** flatMap(mapper, combiner)のサンプル */
public class FlatMapSample2 {
  
  public static void main(String[] args) throws Exception {
    Flowable<String> flowable = Flowable.range(1, 3)
        // flatMap(mapper, maxConcurrency)
        .flatMap(
            // データを受け取ったら新しいFlowableを生成
            data -> {
              return Flowable.interval(100L, TimeUnit.MILLISECONDS)
                  // 3件まで
                  .take(3);
            },
            // 元のデータと変換したデータを使って新たな通知するデータを生成
            (sourceData, newData) -> "[" + sourceData + "] " + newData);
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(1000L);
  }
}
