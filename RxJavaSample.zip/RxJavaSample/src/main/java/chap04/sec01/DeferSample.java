package chap04.sec01;

import java.time.LocalTime;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** defer(supplier)のサンプル */
public class DeferSample<T> {
  
  public static void main(String[] args) throws Exception {
    
    Flowable<LocalTime> flowable =
        Flowable.defer(() -> Flowable.just(LocalTime.now()));
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>("No. 1"));
    
    // しばらく待つ
    Thread.sleep(2000L);
    
    // 再講読する
    flowable.subscribe(new DebugSubscriber<>("No. 2"));
  }
  
}
