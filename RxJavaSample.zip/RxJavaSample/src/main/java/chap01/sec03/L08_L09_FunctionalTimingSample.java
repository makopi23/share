package chap01.sec03;

import io.reactivex.Flowable;

/** リスト8：値を受け取る場合 / リスト9：関数型インターフェースを受け取る場合 */
public class L08_L09_FunctionalTimingSample {
  
  public static void main(String[] args) throws Exception {
    // 値を受け取る場合
    Flowable<Long> flowable1 = Flowable.just(System.currentTimeMillis());
    // 関数型インターフェースを受け取る場合
    Flowable<Long> flowable2 =
        Flowable.fromCallable(() -> System.currentTimeMillis());
    
    flowable1.subscribe(data -> System.out.println("flowable1: " + data));
    flowable2.subscribe(data -> System.out.println("flowable2: " + data));
    
    // しばらく待つ
    Thread.sleep(1000L);
    
    // 再度実行
    flowable1.subscribe(data -> System.out.println("flowable1: " + data));
    flowable2.subscribe(data -> System.out.println("flowable2: " + data));
  }
  
}
