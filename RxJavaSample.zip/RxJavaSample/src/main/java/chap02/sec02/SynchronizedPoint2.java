package chap02.sec02;

/** リスト15：synchronizedメソッドに変換した場合 */
class SynchronizedPoint2 {
  
  private int x;
  
  private int y;
  
  synchronized void rightUp() {
    x++;
    y++;
  }
  
  synchronized int getX() {
    return x;
  }
  
  synchronized int getY() {
    return y;
  }
}
