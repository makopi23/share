package chap03.sec02;

import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;
import io.reactivex.subscribers.ResourceSubscriber;

/** リスト7：メインスレッドではないスレッド上で処理を行うFlowableの場合 */
public class L07_NonMainThreadSample {
  
  public static void main(String[] args) throws Exception {
    System.out.println("start");
    
    Flowable.interval(300L, TimeUnit.MILLISECONDS)
        // 購読する
        .subscribe(new ResourceSubscriber<Long>() {
          
          @Override
          public void onNext(Long data) {
            String threadName = Thread.currentThread().getName();
            System.out.println(threadName + ": " + data);
          }
          
          @Override
          public void onComplete() {
            String threadName = Thread.currentThread().getName();
            System.out.println(threadName + ": 完了");
          }
          
          @Override
          public void onError(Throwable error) {
            error.printStackTrace();
          }
        });
    
    System.out.println("end");
    
    // しばらく待つ
    Thread.sleep(1000L);
  }
  
}
