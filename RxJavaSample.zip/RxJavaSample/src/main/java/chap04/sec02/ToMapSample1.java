package chap04.sec02;

import java.util.Map;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** toMap(keySelector)のサンプル */
public class ToMapSample1 {
  
  public static void main(String[] args) {
    
    Single<Map<Long, String>> single =
        // Flowableの生成
        Flowable.just("1A", "2B", "3C", "1D", "2E")
            // データから生成したキーとデータの組み合わせのMapを通知
            .toMap(data -> Long.valueOf(data.substring(0, 1)));
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
  }
}
