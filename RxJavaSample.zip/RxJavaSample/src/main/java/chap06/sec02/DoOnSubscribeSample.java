package chap06.sec02;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;

/** doOnSubscribe(onSubscribe)のサンプル */
public class DoOnSubscribeSample {
  
  public static void main(String[] args) throws Exception {
    
    // Flowableの生成
    Flowable.range(1, 5)
        // 購読開始時のログ
        .doOnSubscribe(subscription -> System.out.println("doOnSubscribe"))
        // 購読する
        .subscribe(new Subscriber<Integer>() {
          
          @Override
          public void onSubscribe(Subscription subscription) {
            System.out.println("--- Subscriber: onSubscribe");
            subscription.request(Long.MAX_VALUE);
          }
          
          @Override
          public void onNext(Integer data) {
            System.out.println("--- Subscriber: onNext: " + data);
          }
          
          @Override
          public void onComplete() {
            // 何もしない
          }
          
          @Override
          public void onError(Throwable error) {
            // 何もしない
          }
        });
  }
  
}
