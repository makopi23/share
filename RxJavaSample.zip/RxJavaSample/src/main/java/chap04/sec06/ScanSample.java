package chap04.sec06;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** scan(initialValue, accumulator)のサンプル */
public class ScanSample {
  
  public static void main(String[] args) throws Exception {
    
    Flowable<Integer> flowable =
        // 引数のデータを通知するFlowableを生成
        Flowable.just(1, 10, 100, 1000, 10000)
            // scanメソッドを使って受け取ったデータを加算する
            .scan(0, (sum, data) -> sum + data);
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
  
}
