package chap06.sec05;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import io.reactivex.Flowable;
import io.reactivex.schedulers.TestScheduler;
import io.reactivex.subscribers.TestSubscriber;

public class TestSchedulerTest {
  
  /** リスト3：TestSchedulerを使ったサンプル */
  @Test
  public void TestSchedulerを実行してみる() {
    // テスト開始時の時間
    long start = System.currentTimeMillis();
    
    // テスト用のScheduler
    TestScheduler testScheduler = new TestScheduler();
    
    // テスト対象のFlowable
    Flowable<Long> flowable =
        Flowable.interval(500L, TimeUnit.MILLISECONDS, testScheduler);
    
    // 購読を開始する
    TestSubscriber<Long> result = flowable.test();
    
    // Schedulerは進んでいないので何も出力されない
    System.out.println("data=" + result.values());
    result.assertEmpty();
    
    // 500ミリ秒だけ進める
    testScheduler.advanceTimeBy(500L, TimeUnit.MILLISECONDS);
    
    // onNextイベントで受け取ったデータのList
    System.out.println("data=" + result.values());
    result.assertValues(0L);
    
    // さらに500ミリ秒だけ進める
    testScheduler.advanceTimeBy(500L, TimeUnit.MILLISECONDS);
    
    // onNextイベントで受け取ったデータのList
    System.out.println("data=" + result.values());
    result.assertValues(0L, 1L);
    
    // 2000ミリ秒まで進める
    testScheduler.advanceTimeTo(2000L, TimeUnit.MILLISECONDS);
    
    // onNextイベントで受け取ったデータのList
    System.out.println("data=" + result.values());
    result.assertValues(0L, 1L, 2L, 3L);
    
    // 現在の経過時間
    System.out.println(
        "testScheduler.now()=" + testScheduler.now(TimeUnit.MILLISECONDS));
    
    // テストにかかった時間
    long totalTime = System.currentTimeMillis() - start;
    System.out.println("テストにかかった時間=" + totalTime);
  }
}
