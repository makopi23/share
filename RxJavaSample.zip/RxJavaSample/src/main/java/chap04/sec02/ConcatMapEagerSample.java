package chap04.sec02;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** concatMapEager(mapper)のサンプル */
public class ConcatMapEagerSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<String> flowable = Flowable.range(10, 3)
        // 受け取ったデータ元にFlowableを生成しすぐに実行するが通知は順にする
        .concatMapEager(
            // 通知するデータを持つFlowableを生成
            sourceData -> Flowable.interval(500L, TimeUnit.MILLISECONDS)
                // 2件まで
                .take(2)
                // 元の通知データと結果のFlowableのデータを合わせて文字列にする
                .map(data -> {
                  // 通知時のシステム時間もデータに加える
                  long time = System.currentTimeMillis();
                  return time + "ms: [" + sourceData + "] " + data;
                }));
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
