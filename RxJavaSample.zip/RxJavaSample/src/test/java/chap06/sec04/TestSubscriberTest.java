package chap06.sec04;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import io.reactivex.Flowable;
import io.reactivex.subscribers.TestSubscriber;

/** TestSubscriberの使い方の簡単な例 */
public class TestSubscriberTest {
  
  /** リスト1：TestSubscriberの使い方の簡単な例 */
  @Test
  public void TestSubscriberの使い方の簡単な例() throws Exception {
    // 対象となるFlowable
    Flowable<Long> target = Flowable.interval(100L, TimeUnit.MILLISECONDS);
    
    // テスト用のSubscriberの生成し、Flowableの処理を開始する
    TestSubscriber<Long> testSubscriber = target.test();
    
    // まだデータが通知されていないかの確認
    testSubscriber.assertEmpty();
    
    // 指定した時間、待機させる
    // ※非同期処理のため100ミリ秒だと通知されてない可能性がある
    testSubscriber.await(150L, TimeUnit.MILLISECONDS);
    
    // 今まで通知されたデータの確認
    testSubscriber.assertValues(0L);
    
    // 指定した時間、待機させる
    testSubscriber.await(100L, TimeUnit.MILLISECONDS);
    
    // 今まで通知されたデータの確認
    testSubscriber.assertValues(0L, 1L);
  }
  
  /** リスト2：assertメソッドをつなげて記述する場合 */
  @Test
  public void 空のFlowableのテスト() {
    Flowable.empty()
        // TestSubscriberの生成
        .test()
        // データを受け取っていなければ成功
        .assertNoValues()
        // エラーがなければ成功
        .assertNoErrors()
        // 完了していれば成功
        .assertComplete();
  }
}
