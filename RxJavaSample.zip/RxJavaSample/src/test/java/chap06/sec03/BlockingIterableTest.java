package chap06.sec03;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import io.reactivex.Flowable;
import io.reactivex.exceptions.MissingBackpressureException;

/** blockingIterable()のテスト */
public class BlockingIterableTest {
  
  @Test
  public void 各データを取得するIterableを取得する() throws Exception {
    // 取得する結果
    Iterable<Long> result =
        // Flowableの生成
        Flowable.interval(100L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5)
            // Iterableに変換してメインスレッド上で取得する
            .blockingIterable();
    
    // Iteratorの取得
    Iterator<Long> iterator = result.iterator();
    
    // データの有無の確認
    assertTrue(iterator.hasNext());
    
    // データの確認
    assertThat(iterator.next(), is(0L));
    assertThat(iterator.next(), is(1L));
    assertThat(iterator.next(), is(2L));
    
    // しばらく待つ ※バッファサイズを超さないレベル
    Thread.sleep(1000L);
    
    // データの確認
    assertThat(iterator.next(), is(3L));
    assertThat(iterator.next(), is(4L));
    
    // データの有無の確認
    assertFalse(iterator.hasNext());
  }
  
  @Test(expected = NoSuchElementException.class)
  public void 完了後にデータを取得し例外を発生させる() throws Exception {
    // 取得する結果
    Iterable<Long> result =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 3件まで
            .take(3)
            // Iterableに変換してメインスレッド上で取得する
            .blockingIterable();
    
    // Iteratorの取得
    Iterator<Long> iterator = result.iterator();
    assertThat(iterator.next(), is(0L));
    assertThat(iterator.next(), is(1L));
    assertThat(iterator.next(), is(2L));
    
    // 完了後にデータを取得する
    iterator.next();
  }
  
  @Test(expected = MissingBackpressureException.class)
  public void バッファサイズを指定してIterableを取得する() throws Exception {
    // 取得する結果
    Iterable<Long> result =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // Iterableに変換してメインスレッド上で取得する
            .blockingIterable(1);
    
    // Iteratorの取得
    Iterator<Long> iterator = result.iterator();
    
    // データの確認
    assertThat(iterator.next(), is(0L));
    assertThat(iterator.next(), is(1L));
    assertThat(iterator.next(), is(2L));
    
    // しばらく待つ
    Thread.sleep(1000L);
    
    // 再度呼び出すと例外が発生する
    iterator.next();
    
    // ここまで来たら失敗
    fail();
  }
  
  @Test
  public void データがないものをIterableに変換する() {
    // 取得する結果
    Iterable<Long> result =
        // Flowableの生成
        Flowable.<Long> empty()
            // Iterableに変換してメインスレッド上で取得する
            .blockingIterable();
    
    // Iteratorの取得
    Iterator<Long> iterator = result.iterator();
    
    // 確認
    assertFalse(iterator.hasNext());
  }
  
  @Test(expected = MissingBackpressureException.class)
  public void バッファを超した通知を行わせる() throws Exception {
    // 取得する結果
    Iterable<Long> result =
        // Flowableの生成
        Flowable.interval(1L, TimeUnit.MICROSECONDS)
            // Iterableに変換してメインスレッド上で取得する
            .blockingIterable();
    
    // Iteratorの取得
    Iterator<Long> iterator = result.iterator();
    
    // しばらく待ってからデータを取得する
    Thread.sleep(1000L);
    System.out.println("data=" + iterator.next());
    
    // ここまで来たら失敗
    fail();
  }
}
