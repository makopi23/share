package chap06.sec03;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import io.reactivex.Flowable;

/** blockingFirst()のテスト */
public class BlockingFirstTest {
  
  @Test
  public void 最初のデータを取得する() {
    // 取得する結果
    long actual =
        // Flowableの生成
        Flowable.interval(2000L, TimeUnit.MILLISECONDS)
            // 最初に通知されるデータをメインスレッド上で取得する
            .blockingFirst();
    
    // 確認
    assertThat(actual, is(0L));
  }
}
