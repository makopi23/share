package chap03.sec05;

import java.util.concurrent.TimeUnit;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;

/** リスト22：MissingBackpressureExceptionが発生する場合 */
public class L22_MissingBackpressureFlowableSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable = Flowable.interval(10L, TimeUnit.MICROSECONDS)
        // 通知時に情報を出力させる
        .doOnNext(value -> System.out.println("emit: " + value));
    
    flowable
        // 別のスレッドでデータを受け取る
        .observeOn(Schedulers.computation())
        // 購読する
        .subscribe(new Subscriber<Long>() {
          
          @Override
          public void onSubscribe(Subscription subscription) {
            // 無制限にデータを通知させる
            subscription.request(Long.MAX_VALUE);
          };
          
          @Override
          public void onNext(Long value) {
            // 1000ミリ秒待ってから処理を行う
            try {
              System.out.println("waiting......");
              Thread.sleep(1000L);
            } catch (Exception e) {
              e.printStackTrace();
            }
            System.out.println("received: " + value);
          }
          
          @Override
          public void onError(Throwable error) {
            System.out.println("エラー=" + error);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
        });
    
    // しばらく待つ
    Thread.sleep(5000L);
  }
}
