package chap03.sec02;

import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;

/** リスト13：2つのスレッドから同じオブジェクトの更新を行う */
public class L13_CounterSample {
  
  public static void main(String[] args) throws Exception {
    // カウントするオブジェクト
    final Counter counter = new Counter();
    
    // 10,000回Counterのincrementメソッドを呼ぶ
    Flowable.range(1, 10000)
        // Flowableを異なるスレッド上で処理を行うようにする
        .subscribeOn(Schedulers.computation())
        // 異なるスレッド上で処理を行うようにする
        .observeOn(Schedulers.computation())
        // 購読する
        .subscribe(
            // データを受け取った際の処理
            data -> counter.increment(),
            // エラーを受け取った際の処理
            error -> System.out.println("エラー=" + error),
            // 完了の通知を受け取った際の処理
            () -> System.out.println("counter.get()=" + counter.get()));
    
    // 別のスレッドで同時に実行する
    Flowable.range(1, 10000)
        // Flowableを異なるスレッド上で処理を行うようにする
        .subscribeOn(Schedulers.computation())
        // 異なるスレッド上で処理を行うようにする
        .observeOn(Schedulers.computation())
        // 購読する
        .subscribe(
            // データを受け取った際の処理
            data -> counter.increment(),
            // エラーを受け取った際の処理
            error -> System.out.println("エラー=" + error),
            // 完了の通知を受け取った際の処理
            () -> System.out.println("counter.get()=" + counter.get()));
    
    // しばらく待つ
    Thread.sleep(1000L);
  }
}
