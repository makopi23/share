package chap04.sec01;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** justメソッドのサンプル */
public class JustSample<T> {
  
  public static void main(String[] args) {
    
    // 引数のデータを順に通知するFlowableの生成
    Flowable<String> flowable = Flowable.just("A", "B", "C", "D", "E");
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
  
}
