package chap04.sec07;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;

/** timeout(time, unit)のサンプル */
public class TimeoutSample {
  
  public static void main(String[] args) throws Exception {
    
    Flowable<Integer> flowable =
        // Flowableの生成
        Flowable.<Integer> create(emitter -> {
          emitter.onNext(1);
          emitter.onNext(2);
          // しばらく待つ
          try {
            Thread.sleep(1200L);
          } catch (InterruptedException e) {
            // InterruptedExceptionが発生した場合に通知して終了
            emitter.onError(e);
            return;
          }
          emitter.onNext(3);
          emitter.onComplete();
        }, BackpressureStrategy.BUFFER)
            // 1000ミリ秒後にタイムアウトする
            .timeout(1000L, TimeUnit.MILLISECONDS);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
}
