package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** skipLast(count)のサンプル */
public class SkipLastSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(1000L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5)
            // 最後の2件を通知しない
            .skipLast(2);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(6000L);
  }
  
}
