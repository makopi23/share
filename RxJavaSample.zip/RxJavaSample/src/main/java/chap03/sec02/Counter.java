package chap03.sec02;

/** リスト14：順にカウントするクラス */
class Counter {
  private volatile int count;
  
  void increment() {
    count++;
  }
  
  int get() {
    return count;
  }
}
