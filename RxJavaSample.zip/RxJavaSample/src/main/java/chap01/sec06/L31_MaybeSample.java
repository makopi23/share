package chap01.sec06;

import java.time.DayOfWeek;
import java.time.LocalDate;

import io.reactivex.Maybe;
import io.reactivex.MaybeObserver;
import io.reactivex.disposables.Disposable;

/** リスト31：Maybeのサンプル */
public class L31_MaybeSample {
  
  public static void main(String[] args) {
    // Maybeの作成
    Maybe<DayOfWeek> maybe = Maybe.create(emitter -> {
      emitter.onSuccess(LocalDate.now().getDayOfWeek());
    });
    
    // 購読する
    maybe.subscribe(new MaybeObserver<DayOfWeek>() {
      
      /** 購読の準備ができた際の処理を行う */
      @Override
      public void onSubscribe(Disposable disposable) {
        // 何もしない
      }
      
      /** データの通知を受け取った際の処理を行う */
      @Override
      public void onSuccess(DayOfWeek value) {
        System.out.println(value);
      }
      
      /** 完了の通知を受け取った際の処理を行う */
      @Override
      public void onComplete() {
        System.out.println("完了");
      }
      
      /** エラーの通知を受け取った際の処理を行う */
      @Override
      public void onError(Throwable e) {
        System.out.println("エラー=" + e);
      }
    });
  }
  
}
