package chap04.sec01;

import java.util.Arrays;
import java.util.List;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

public class FromIterableSample<T> {
  
  /** fromIterable(source)のサンプル */
  public static void main(String[] args) {
    
    // Listのデータを順に通知するFlowableの生成
    List<String> list = Arrays.asList("A", "B", "C", "D", "E");
    Flowable<String> flowable = Flowable.fromIterable(list);
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
  
}
