package chap04.sec05;

import java.util.concurrent.TimeUnit;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** count()のサンプル */
public class CountSample {
  
  public static void main(String[] args) throws Exception {
    Single<Long> single =
        // Flowableの生成
        Flowable.interval(1000L, TimeUnit.MILLISECONDS)
            // 3件まで
            .take(3)
            // データ数を通知
            .count();
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
