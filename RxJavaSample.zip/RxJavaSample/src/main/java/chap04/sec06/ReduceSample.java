package chap04.sec06;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** reduce(seed, reducer)のサンプル */
public class ReduceSample {
  
  public static void main(String[] args) throws Exception {
    
    Single<Integer> single =
        // 引数のデータを通知するFlowableを生成
        Flowable.just(1, 10, 100, 1000, 10000)
            // reduceメソッドを使って受け取ったデータを加算する
            .reduce(0, (sum, data) -> sum + data);
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
  }
  
}
