package chap04.sec04;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** combineLatest(source1, source2, combiner)のサンプル */
public class CombineLatestSample1 {
  
  public static void main(String[] args) throws Exception {
    // 結合対象
    Flowable<Long> flowable1 =
        // 300ミリ秒ごとにデータを通知する
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5);
    
    // 結合対象
    Flowable<Long> flowable2 =
        // 500ミリ秒ごとにデータを通知する
        Flowable.interval(500L, TimeUnit.MILLISECONDS)
            // 3件まで
            .take(3)
            // 100加算する
            .map(data -> data + 100L);
    
    // 複数のFlowableから受け取ったデータで新しいデータを生成する
    Flowable<List<Long>> result = Flowable.combineLatest(
        // 結合するFlowable
        flowable1,
        // 結合するFlowable
        flowable2,
        // 引数より通知されたデータをListに格納して通知
        (data1, data2) -> Arrays.asList(data1, data2));
    
    // 購読する
    result.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
  
}
