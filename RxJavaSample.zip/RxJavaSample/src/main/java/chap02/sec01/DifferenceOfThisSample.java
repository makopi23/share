package chap02.sec01;

import io.reactivex.functions.Action;

/** リスト4：thisの出力例（ラムダ式と匿名クラスのthisの比較） */
public class DifferenceOfThisSample {
  
  public static void main(String[] args) throws Exception {
    DifferenceOfThisSample target = new DifferenceOfThisSample();
    target.execute();
  }
  
  /** 匿名クラスとラムダ式内のthisについて標準出力する */
  public void execute() throws Exception {
    // 匿名クラス
    Action anonymous = new Action() {
      
      @Override
      public void run() {
        System.out.println("匿名クラスの場合: " + this);
      }
    };
    
    // ラムダ式
    Action lambda = () -> System.out.println("ラムダ式の場合: " + this);
    
    // それぞれ実行する
    anonymous.run();
    lambda.run();
  }
  
  @Override
  public String toString() {
    return this.getClass().getSimpleName();
  }
}
