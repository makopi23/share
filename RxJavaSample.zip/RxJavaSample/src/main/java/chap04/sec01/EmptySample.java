package chap04.sec01;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** empty()のサンプル */
public class EmptySample<T> {
  
  public static void main(String[] args) {
    
    Flowable
        // 空のFlowableの生成
        .empty()
        // 購読する
        .subscribe(new DebugSubscriber<>());
  }
  
}
