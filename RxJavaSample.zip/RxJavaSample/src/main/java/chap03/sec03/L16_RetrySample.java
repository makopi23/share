package chap03.sec03;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;

/** リスト16：リトライをする場合 */
public class L16_RetrySample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Integer> flowable = Flowable.<Integer> create(emitter -> {
      // Flowableの処理の開始
      System.out.println("Flowableの処理開始");
      // 通知処理
      for (int i = 1; i <= 3; i++) {
        // データが「2」の時にエラーを発生させる
        if (i == 2) {
          throw new Exception("例外発生");
        }
        // データの通知
        emitter.onNext(i);
      }
      // 完了の通知
      emitter.onComplete();
      // Flowableの処理の衆力
      System.out.println("Flowableの処理終了");
    }, BackpressureStrategy.BUFFER)
        // doOnSubscribeの実行
        .doOnSubscribe(
            subscription -> System.out.println("flowable: doOnSubscribe"))
        // エラーが発生したら2回まで再実行する
        .retry(2);
    
    // 購読する
    flowable.subscribe(new Subscriber<Integer>() {
      
      @Override
      public void onSubscribe(Subscription subscription) {
        System.out.println("subscriber: onSubscribe");
        subscription.request(Long.MAX_VALUE);
      }
      
      @Override
      public void onNext(Integer data) {
        System.out.println("data=" + data);
      }
      
      @Override
      public void onError(Throwable error) {
        System.out.println("エラー=" + error);
      }
      
      @Override
      public void onComplete() {
        System.out.println("完了");
      }
    });
  }
}
