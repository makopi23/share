package chap04.sec01;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** range(start, count)のサンプル */
public class RangeSample<T> {
  
  public static void main(String[] args) {
    
    // 10から順に3件まで通知するFlowableの生成
    Flowable<Integer> flowable = Flowable.range(10, 3);
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
  
}
