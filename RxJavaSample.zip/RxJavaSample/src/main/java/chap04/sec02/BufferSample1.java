package chap04.sec02;

import java.util.List;
import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** buffer(count)のサンプル */
public class BufferSample1 {
  
  public static void main(String[] args) throws Exception {
    
    Flowable<List<Long>> flowable =
        // 100ミリ秒ごとに数値を通知するFlowableを生成
        Flowable.interval(100L, TimeUnit.MILLISECONDS)
            // 10件まで
            .take(10)
            // 3件ずつにまとめて通知する
            .buffer(3);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
  
}
