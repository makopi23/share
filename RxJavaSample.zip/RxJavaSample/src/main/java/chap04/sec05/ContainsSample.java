package chap04.sec05;

import java.util.concurrent.TimeUnit;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** contains(item)のサンプル */
public class ContainsSample {
  
  public static void main(String[] args) throws Exception {
    Single<Boolean> single =
        // Flowableの生成
        Flowable.interval(1000L, TimeUnit.MILLISECONDS)
            // 引数のデータが含まれているか判定
            .contains(3L);
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
