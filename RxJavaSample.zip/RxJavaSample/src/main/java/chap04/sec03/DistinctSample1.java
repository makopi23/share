package chap04.sec03;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** distinct()のサンプル */
public class DistinctSample1 {
  
  public static void main(String[] args) {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.just("A", "a", "B", "b", "A", "a", "B", "b")
            // 重複したデータを除いて通知する
            .distinct();
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
  }
}
