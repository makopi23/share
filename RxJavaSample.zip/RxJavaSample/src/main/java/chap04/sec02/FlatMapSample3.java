package chap04.sec02;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** flatMap(onNextMapper, onErrorMapper, onCompleteSupplier)のサンプル */
public class FlatMapSample3 {
  
  public static void main(String[] args) throws Exception {
    // エラーが発生するFlawable
    Flowable<Integer> original = Flowable.just(1, 2, 0, 4, 5)
        // 0が来たら例外を発生させる
        .map(data -> 10 / data);
    
    // 通常時、エラー発生時、完了時の通知を指定したデータに変換する
    Flowable<Integer> flowable = original.flatMap(
        // 通常時のデータ
        data -> Flowable.just(data),
        // エラー時のデータ
        error -> Flowable.just(-1),
        // 完了時のデータ
        () -> Flowable.just(100));
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
}
