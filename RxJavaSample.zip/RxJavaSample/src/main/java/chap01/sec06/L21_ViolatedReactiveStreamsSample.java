package chap01.sec06;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;

/** リスト21：onSubscribeメソッドの途中で処理が始まる例 */
public class L21_ViolatedReactiveStreamsSample {
  
  public static void main(String[] args) {
    Flowable.range(1, 3)
        // 購読する
        .subscribe(new Subscriber<Integer>() {
          @Override
          public void onSubscribe(Subscription subscription) {
            System.out.println("onSubscribe: start");
            subscription.request(Long.MAX_VALUE);
            System.out.println("onSubscribe: end");
          }
          
          @Override
          public void onNext(Integer data) {
            System.out.println(data);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
          
          @Override
          public void onError(Throwable error) {
            System.out.println("エラー=" + error);
          }
        });
  }
  
}
