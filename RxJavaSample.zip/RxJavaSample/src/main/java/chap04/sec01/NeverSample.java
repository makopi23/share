package chap04.sec01;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** never()のサンプル */
public class NeverSample<T> {
  
  public static void main(String[] args) {
    
    Flowable
        // 何も通知しないFlowableの生成
        .never()
        // 購読開始
        .subscribe(new DebugSubscriber<>());
  }
  
}
