package chap03.sec02;

import io.reactivex.Flowable;
import io.reactivex.subscribers.ResourceSubscriber;

/** リスト6：メインスレッド上で処理を行うFlowableの場合 */
public class L06_MainThreadSample {
  
  public static void main(String[] args) {
    System.out.println("start");
    
    Flowable.just(1, 2, 3)
        // 購読する
        .subscribe(new ResourceSubscriber<Integer>() {
          
          @Override
          public void onNext(Integer data) {
            String threadName = Thread.currentThread().getName();
            System.out.println(threadName + ": " + data);
          }
          
          @Override
          public void onComplete() {
            String threadName = Thread.currentThread().getName();
            System.out.println(threadName + ": 完了");
          }
          
          @Override
          public void onError(Throwable error) {
            error.printStackTrace();
          }
        });
    
    System.out.println("end");
  }
  
}
