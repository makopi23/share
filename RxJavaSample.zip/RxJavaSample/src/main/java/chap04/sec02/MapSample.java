package chap04.sec02;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** map(mapper)のサンプル */
public class MapSample {
  
  public static void main(String[] args) throws Exception {
    
    Flowable<String> flowable =
        // 引数のデータを順に通知するFlowableの生成
        Flowable.just("A", "B", "C", "D", "E")
            // mapメソッドを使って小文字に変換
            .map(data -> data.toLowerCase());
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
}
