package chap04.sec01;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** fromCallable(supplier)のサンプル */
public class FromCallableSample<T> {
  
  public static void main(String[] args) {
    
    // Callableの結果を通知するFlowableの生成
    Flowable<Long> flowable =
        Flowable.fromCallable(() -> System.currentTimeMillis());
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
}
