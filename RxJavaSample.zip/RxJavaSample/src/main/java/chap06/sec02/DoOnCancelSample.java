package chap06.sec02;

import java.util.concurrent.TimeUnit;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;

/** doOnCancel(onCancel)のサンプル */
public class DoOnCancelSample {
  
  public static void main(String[] args) throws Exception {
    
    // Flowableの生成
    Flowable.interval(100L, TimeUnit.MILLISECONDS)
        // 購読解除時のログ
        .doOnCancel(() -> System.out.println("doOnCancel"))
        // 購読する
        .subscribe(new Subscriber<Long>() {
          
          private long startTime;
          private Subscription subscription;
          
          @Override
          public void onSubscribe(Subscription subscription) {
            this.startTime = System.currentTimeMillis();
            this.subscription = subscription;
            this.subscription.request(Long.MAX_VALUE);
          }
          
          @Override
          public void onNext(Long data) {
            // 購読開始より300ミリ秒過ぎていれば購読を解除し処理を終える
            if (System.currentTimeMillis() - startTime > 300L) {
              System.out.println("購読を解除");
              subscription.cancel();
              return;
            }
            
            System.out.println(data);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
          
          @Override
          public void onError(Throwable error) {
            System.out.println("エラー： " + error);
          }
          
        });
    
    // しばらく待つ
    Thread.sleep(1000L);
  }
  
}
