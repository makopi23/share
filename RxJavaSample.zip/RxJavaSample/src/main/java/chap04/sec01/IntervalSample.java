package chap04.sec01;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;

/** interval(time, unit)のサンプル */
public class IntervalSample<T> {
  
  public static void main(String[] args) throws Exception {
    // 「分:秒.ミリ秒」の文字列に変換するFormatter
    final DateTimeFormatter formatter =
        DateTimeFormatter.ofPattern("mm:ss.SSS");
    
    // 1000ミリ秒ごとに数値を通知するFlowableの生成
    Flowable<Long> flowable = Flowable.interval(1000L, TimeUnit.MILLISECONDS);
    
    // 処理を開始する前の時間
    System.out.println("開始時間: " + LocalTime.now().format(formatter));
    
    // 購読する
    flowable.subscribe(data -> {
      // Thread名の取得
      String threadName = Thread.currentThread().getName();
      // 現在時刻の「分:秒.ミリ秒」を取得
      String time = LocalTime.now().format(formatter);
      // 出力
      System.out.println(threadName + ": " + time + ": data=" + data);
    });
    
    // しばらく待つ
    Thread.sleep(5000L);
  }
  
}
