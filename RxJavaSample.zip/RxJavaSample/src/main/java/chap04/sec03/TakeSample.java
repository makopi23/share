package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** take(count)のサンプル */
public class TakeSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(1000L, TimeUnit.MILLISECONDS)
            // 3件まで通知する
            .take(3);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
