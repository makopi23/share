package chap04.sec02;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** toMultimap(keySelector)のサンプル */
public class ToMultimapSample {
  
  public static void main(String[] args) throws Exception {
    
    Single<Map<String, Collection<Long>>> single =
        // Flowableの生成
        Flowable.interval(500L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5)
            // データから生成したキーごとに格納したMapを通知する
            .toMultimap(data -> {
              if (data % 2 == 0) {
                return "偶数";
              } else {
                return "奇数";
              }
            });
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
}
