package chap04.sec07;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** repeat(times)のサンプル */
public class RepeatSample {
  
  public static void main(String[] args) {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.just("A", "B", "C")
            // 通知を繰り返す
            .repeat(2);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
  }
}
