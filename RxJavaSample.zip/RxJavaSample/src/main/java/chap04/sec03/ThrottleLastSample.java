package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** throttleLast(time, unit)のサンプル */
public class ThrottleLastSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 9件まで
            .take(9)
            // 間隔内の最後のデータを通知する
            .throttleLast(200L, TimeUnit.MILLISECONDS);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
}
