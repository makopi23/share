package chap03.sec02;

import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;

/** リスト10：flatMapメソッド内で異なるスレッド上で動くFlowableを生成した場合 */
public class L10_FlatMapSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.just("A", "B", "C")
            // 受け取ったデータからFlowableを生成し、それが持つデータを通知する
            .flatMap(data -> {
              // 1000ミリ秒遅れてデータを通知するFlowableを生成
              return Flowable.just(data).delay(1000L, TimeUnit.MILLISECONDS);
            });
    
    // 購読する
    flowable.subscribe(data -> {
      String threadName = Thread.currentThread().getName();
      System.out.println(threadName + ": " + data);
    });
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
}
