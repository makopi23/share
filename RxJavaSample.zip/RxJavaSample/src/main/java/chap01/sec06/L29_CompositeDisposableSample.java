package chap01.sec06;

import io.reactivex.Flowable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

/** リスト29：CompositeDisposableのサンプル */
public class L29_CompositeDisposableSample {
  
  public static void main(String[] args) throws Exception {
    // Disposableをまとめる
    CompositeDisposable compositeDisposable = new CompositeDisposable();
    
    compositeDisposable.add(Flowable.range(1, 3)
        // 購読解除時にログ出力
        .doOnCancel(() -> System.out.println("No.1 canceld"))
        // 非同期で実行する
        .observeOn(Schedulers.computation())
        // 購読する
        .subscribe(data -> {
          try {
            Thread.sleep(100L);
            System.out.println("No.1: " + data);
          } catch (InterruptedException e) {
            // dispose()の際に例外が発生するが今回の検証対象ではないので何もしない
          }
        }));
    
    compositeDisposable.add(Flowable.range(1, 3)
        // 購読解除時にログ出力
        .doOnCancel(() -> System.out.println("No.2 canceld"))
        // 非同期で実行する
        .observeOn(Schedulers.computation())
        // 購読する
        .subscribe(data -> {
          try {
            Thread.sleep(100L);
            System.out.println("No.2: " + data);
          } catch (InterruptedException e) {
            // dispose()の際に例外が発生するが今回の検証対象ではないので何もしない
          }
        }));
    
    // しばらく待つ
    Thread.sleep(150L);
    
    // まとめて購読の解除を行う
    compositeDisposable.dispose();
    
    // しばらく待つ
    Thread.sleep(150L);
  }
  
}
