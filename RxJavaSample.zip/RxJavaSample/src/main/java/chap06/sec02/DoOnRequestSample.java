package chap06.sec02;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;

/** doOnRequest(size)のサンプル */
public class DoOnRequestSample {
  
  public static void main(String[] args) throws Exception {
    
    // Flowableの生成
    Flowable.range(1, 3)
        // データ数リクエスト時のログ
        .doOnRequest(size -> System.out.println("オリジナル: size=" + size))
        // Subscriberの処理を別スレッド上で行わせる
        .observeOn(Schedulers.computation())
        // データ数リクエスト時のログ
        .doOnRequest(size -> System.out.println("--- observeOn後: size=" + size))
        // 購読する
        .subscribe(new Subscriber<Integer>() {
          
          private Subscription subscription;
          
          @Override
          public void onSubscribe(Subscription subscription) {
            this.subscription = subscription;
            this.subscription.request(1);
          }
          
          @Override
          public void onNext(Integer data) {
            System.out.println(data);
            subscription.request(1);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
          
          @Override
          public void onError(Throwable error) {
            System.out.println("エラー: " + error);
          }
        });
    
    // しばらく待つ
    Thread.sleep(500L);
  }
}
