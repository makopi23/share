package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** sample(sampler)のサンプル */
public class SampleSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 9件まで
            .take(9)
            // 引数のFlowableがデータを通知した際の最後のデータを通知する
            .sample(Flowable.interval(1000L, TimeUnit.MILLISECONDS));
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
}
