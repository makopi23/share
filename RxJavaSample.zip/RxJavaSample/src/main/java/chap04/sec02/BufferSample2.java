package chap04.sec02;

import java.util.List;
import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** buffer(boundaryIndicatorSupplier)のサンプル */
public class BufferSample2 {
  
  public static void main(String[] args) throws Exception {
    Flowable<List<Long>> flowable =
        // 300ミリ秒ごとに数値を通知するFlowable
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 7件まで
            .take(7)
            // バッファする区切りとなるFlowableを生成する
            .buffer(
                // 1000ミリ秒後にデータを通知する
                () -> Flowable.timer(1000L, TimeUnit.MILLISECONDS));
    
    // 通知する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
