package chap04.sec05;

import java.util.concurrent.TimeUnit;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** sequenceEqual(source1, source2)のサンプル */
public class SequnceEqualSample {
  
  public static void main(String[] args) throws Exception {
    // 比較対象
    Flowable<Long> flowable1 =
        Flowable.interval(1000L, TimeUnit.MILLISECONDS).take(3);
    
    // 比較対象
    Flowable<Long> flowable2 = Flowable.just(0L, 1L, 2L);
    
    // 同じデータを同じ順で同じ数だけ持つのかを判定
    Single<Boolean> single = Flowable.sequenceEqual(flowable1, flowable2);
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
    
    // しばらく待つ
    Thread.sleep(4000L);
  }
  
}
