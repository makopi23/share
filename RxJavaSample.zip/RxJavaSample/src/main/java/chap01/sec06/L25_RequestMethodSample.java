package chap01.sec06;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;

/** リスト25：onSubscribeメソッドないでrequestメソッドを呼んだ場合 */
public class L25_RequestMethodSample {
  
  public static void main(String[] args) {
    Flowable
        // 引数のデータを通知する
        .just(1, 2, 3)
        // 購読する
        .subscribe(new Subscriber<Integer>() {
          
          @Override
          public void onSubscribe(Subscription subscription) {
            System.out.println("onSubscribe START");
            subscription.request(Long.MAX_VALUE);
            System.out.println("onSubscribe END");
          }
          
          @Override
          public void onNext(Integer data) {
            System.out.println(data);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
          
          @Override
          public void onError(Throwable error) {
            System.err.println("エラー=" + error);
          }
        });
  }
  
}
