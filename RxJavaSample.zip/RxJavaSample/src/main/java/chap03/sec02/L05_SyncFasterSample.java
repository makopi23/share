package chap03.sec02;

import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;

/** リスト5：データを受け取る側がインターバル時間より短い時間で処理する場合 */
public class L05_SyncFasterSample {
  
  public static void main(String[] args) throws Exception {
    Flowable.interval(1000L, TimeUnit.MILLISECONDS)
        // データ通知時のシステム時間を出力する
        .doOnNext(data -> System.out
            .println("emit: " + System.currentTimeMillis() + ": " + data))
        // 購読する
        .subscribe(data -> Thread.sleep(500L)); // Subscriberで重い処理をしていると見なす
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
  
}
