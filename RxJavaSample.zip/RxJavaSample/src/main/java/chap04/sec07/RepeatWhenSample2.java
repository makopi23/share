package chap04.sec07;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** repeatWhen(handler)のサンプル ※元のFlowableが異なるスレッド上で処理をする場合 */
public class RepeatWhenSample2 {
  
  public static void main(String[] args) throws Exception {
    
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.interval(100L, TimeUnit.MILLISECONDS)
            // 3件まで
            .take(3)
            // 通知の繰り返しの制御をする
            .repeatWhen(completeHandler -> {
              return completeHandler
                  // 通知のタイミングを遅らせる
                  .delay(1000L, TimeUnit.MILLISECONDS)
                  // 2件まで
                  .take(2)
                  // 通知のタイミングで情報を出力
                  .doOnNext(data -> System.out.println("emit: " + data))
                  .doOnComplete(() -> System.out.println("complete"));
            })
            // データにシステム時間を追加する
            .map(data -> {
              long time = System.currentTimeMillis();
              return time + "ms: " + data;
            });
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(5000L);
  }
}
