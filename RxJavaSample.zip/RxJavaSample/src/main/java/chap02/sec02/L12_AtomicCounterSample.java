package chap02.sec02;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

/** リスト12：AtomicCounterを使った場合 */
public class L12_AtomicCounterSample {
  
  public static void main(String[] args) throws Exception {
    // カウントするオブジェクト
    final AtomicCounter counter = new AtomicCounter();
    
    // 10,000回カウントする非同期のタスクを作成
    Runnable task = () -> {
      for (int i = 0; i < 10000; i++) {
        counter.increment();
      }
    };
    
    // 非同期タスクの生成の準備
    ExecutorService executorService = Executors.newCachedThreadPool();
    
    // 新しいスレッドで開始
    Future<Boolean> future1 = executorService.submit(task, true);
    // 新しいスレッドで開始
    Future<Boolean> future2 = executorService.submit(task, true);
    
    // 結果が返ってくるまで待つ
    if (future1.get() && future2.get()) {
      // 結果を標準出力
      System.out.println(counter.get());
    } else {
      System.err.println("失敗しました");
    }
    
    // 非同期タスクをシャットダウンする
    executorService.shutdown();
  }
  
  /** スレッドセーフである順にカウントするクラス */
  private static class AtomicCounter {
    
    private final AtomicInteger count = new AtomicInteger(0);
    
    void increment() {
      count.incrementAndGet();
    }
    
    int get() {
      return count.get();
    }
    
  }
  
}
