package chap06.sec02;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** リスト2：doOnNext(onNext)のサンプル */
public class DoOnNextSample {
  
  public static void main(String[] args) throws Exception {
    
    // Flowableの生成
    Flowable.range(1, 5)
        // データ通知時のログ
        .doOnNext(data -> System.out.println("--- オリジナル: " + data))
        // 偶数だけにする
        .filter(data -> data % 2 == 0)
        // データ通知時のログ
        .doOnNext(data -> System.out.println("------ filter後: " + data))
        // 購読する
        .subscribe(new DebugSubscriber<>());
  }
}
