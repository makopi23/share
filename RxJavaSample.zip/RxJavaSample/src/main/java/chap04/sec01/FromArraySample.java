package chap04.sec01;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** fromArray(items)のサンプル */
public class FromArraySample<T> {
  
  public static void main(String[] args) {
    
    // 配列のデータを順に通知するFlowableの生成
    Flowable<String> flowable = Flowable.fromArray("A", "B", "C", "D", "E");
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
  
}
