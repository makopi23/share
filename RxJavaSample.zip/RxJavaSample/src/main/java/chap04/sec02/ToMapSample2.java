package chap04.sec02;

import java.util.Map;

import chap04.DebugSingleObserver;
import io.reactivex.Flowable;
import io.reactivex.Single;

/** toMap(keySelector, valueSelector)のサンプル */
public class ToMapSample2 {
  
  public static void main(String[] args) {
    
    Single<Map<Long, String>> single =
        // Flowableの生成
        Flowable.just("1A", "2B", "3C", "1D", "2E")
            // データから生成したキーと値の組み合わせのMapを通知
            .toMap(
                // 第1引数： キーの作成
                data -> Long.valueOf(data.substring(0, 1)),
                // 第2引数：値の作成
                data -> data.substring(1));
    
    // 購読する
    single.subscribe(new DebugSingleObserver<>());
  }
}
