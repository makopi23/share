package chap04.sec04;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** startWith(other)のサンプル */
public class StartWithSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // 300ミリ秒ごとにデータを通知する
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 5件まで
            .take(5);
    
    // 結合対象
    Flowable<Long> other =
        // 500ミリ秒ごとにデータを通知する
        Flowable.interval(500L, TimeUnit.MILLISECONDS)
            // 2件まで
            .take(2)
            // 100加算する
            .map(data -> data + 100L);
    
    // 引数のFlowableを先に実行する
    Flowable<Long> result = flowable.startWith(other);
    
    // 購読する
    result.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
  
}
