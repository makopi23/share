package chap04.sec02;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** flatMap(mapper)のサンプル */
public class FlatMapSample1 {
  
  public static void main(String[] args) throws Exception {
    // 引数のデータを順に通知するFlowableの生成
    Flowable<String> flowable = Flowable.just("A", "", "B", "", "C")
        // flatMapメソッドを使って空文字を除きかつ小文字に変換
        .flatMap(data -> {
          if ("".equals(data)) {
            // 空文字なら空のFlowableを返す
            return Flowable.empty();
          } else {
            // 小文字に変換したデータを持つFlowableを返す
            return Flowable.just(data.toLowerCase());
          }
        });
    
    // 購読開始
    flowable.subscribe(new DebugSubscriber<>());
  }
}
