package chap03.sec01;

import java.util.Arrays;
import java.util.List;

import io.reactivex.Flowable;
import io.reactivex.functions.Consumer;

/** リスト3：Flowableを使った場合 */
public class L03_FlowableSample {
  
  public static void main(String[] args) {
    // ListからFlowableを作成
    List<String> list = Arrays.asList("a", "b", "c");
    Flowable<String> flowable = Flowable.fromIterable(list);
    
    // 処理を開始
    flowable.subscribe(new Consumer<String>() {
      
      @Override
      public void accept(String value) throws Exception {
        // 通知されたデータを標準出力する
        System.out.println(value);
      }
    });
  }
  
}
