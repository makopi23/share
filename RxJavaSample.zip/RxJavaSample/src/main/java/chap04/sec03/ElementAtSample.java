package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugMaybeObserver;
import io.reactivex.Flowable;
import io.reactivex.Maybe;

/** elementAt(index)のサンプル */
public class ElementAtSample {
  
  public static void main(String[] args) throws Exception {
    Maybe<Long> maybe =
        // Flowableの生成
        Flowable.interval(100L, TimeUnit.MILLISECONDS)
            // インデックスが3（0始まり）のデータのみを通知する
            .elementAt(3);
    
    // 購読する
    maybe.subscribe(new DebugMaybeObserver<>());
    
    // しばらく待つ
    Thread.sleep(1000L);
  }
  
}
