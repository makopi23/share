package chap05.sec02;

import chap04.DebugSubscriber;
import io.reactivex.processors.PublishProcessor;

/** リスト2：PublishProcessorのサンプル */
public class L02_PublishProcessorSample {
  
  public static void main(String[] args) throws Exception {
    
    // Processorの生成
    PublishProcessor<Integer> processor = PublishProcessor.create();
    
    // 通知前にSubscriberに購読させる
    processor.subscribe(new DebugSubscriber<>("No.1"));
    
    // データを通知する
    processor.onNext(1);
    processor.onNext(2);
    processor.onNext(3);
    
    // 別のSubscriberにも購読させる
    System.out.println("Subscriber No.2 追加");
    processor.subscribe(new DebugSubscriber<>("--- No.2"));
    
    // データを通知する
    processor.onNext(4);
    processor.onNext(5);
    
    // 完了を通知する
    processor.onComplete();
    
    // 完了後にも別のSubscriberにも購読させる
    System.out.println("Subscriber No.3 追加");
    processor.subscribe(new DebugSubscriber<>("------ No.3"));
  }
}
