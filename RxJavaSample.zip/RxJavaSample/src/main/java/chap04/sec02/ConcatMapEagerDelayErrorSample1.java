package chap04.sec02;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** concatMapEagerDelayError(mapper, tillTheEnd)のサンプル（tillTheEnd=trueの場合） */
public class ConcatMapEagerDelayErrorSample1 {
  
  public static void main(String[] args) throws Exception {
    
    Flowable<String> flowable = Flowable.range(10, 3)
        // データからFlowableを生成し実行するが通知は受け取ったデータ順にする
        .concatMapEagerDelayError(
            // 第1引数：通知するデータを持つFlowableを生成
            sourceData -> Flowable.interval(500L, TimeUnit.MILLISECONDS)
                // 3件まで
                .take(3)
                // 「[11] 1」を通知する際に例外を発生させる
                .doOnNext(data -> {
                  if (sourceData == 11 && data == 1) {
                    throw new Exception("例外発生");
                  }
                })
                // 元の通知データと結果のFlowableのデータを合わせて文字列にする
                .map(data -> "[" + sourceData + "] " + data),
            // 第2引数：エラーを通知するタイミングの設定
            true);
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    // しばらく待つ
    Thread.sleep(4000L);
  }
}
