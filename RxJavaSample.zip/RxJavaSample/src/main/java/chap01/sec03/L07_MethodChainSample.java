package chap01.sec03;

import io.reactivex.Flowable;

/** リスト7：メソッドチェインのサンプル */
public class L07_MethodChainSample {
  
  public static void main(String[] args) {
    Flowable<Integer> flowable =
        // 引数のデータを順に通知するFlowableの生成
        Flowable.just(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
            // 通知するデータを偶数のみにする
            .filter(data -> data % 2 == 0)
            // データを100倍する
            .map(data -> data * 100);
    
    // 購読し受け取ったデータを出力する
    flowable.subscribe(data -> System.out.println("data=" + data));
  }
  
}
