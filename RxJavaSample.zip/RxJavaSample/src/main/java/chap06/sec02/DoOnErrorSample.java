package chap06.sec02;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** doOnError(onError)のサンプル */
public class DoOnErrorSample {
  
  public static void main(String[] args) throws Exception {
    
    // Flowableの生成
    Flowable.range(1, 5)
        // エラーの通知時のログ
        .doOnError(error -> System.out.println("オリジナル: " + error.getMessage()))
        // 「3」の時にエラーを発生させる
        .map(data -> {
          if (data == 3) {
            throw new Exception("例外発生");
          }
          return data;
        })
        // エラーの通知時のログ
        .doOnError(
            error -> System.out.println("--- map後: " + error.getMessage()))
        // 購読する
        .subscribe(new DebugSubscriber<>());
  }
}
