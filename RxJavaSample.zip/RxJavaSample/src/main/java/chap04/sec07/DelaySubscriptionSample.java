package chap04.sec07;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;

/** delaySubscription(time, unit)のサンプル */
public class DelaySubscriptionSample {
  
  public static void main(String[] args) throws Exception {
    // 処理の開始時間の出力
    System.out.println("処理開始： " + System.currentTimeMillis());
    
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.<String> create(emitter -> {
          // 購読の開始時間の出力
          System.out.println("購読開始： " + System.currentTimeMillis());
          // データの通知
          emitter.onNext("A");
          emitter.onNext("B");
          emitter.onNext("C");
          // 完了の通知
          emitter.onComplete();
        }, BackpressureStrategy.BUFFER)
            // 処理の開始を遅らせる
            .delaySubscription(2000L, TimeUnit.MILLISECONDS);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(3000L);
  }
}
