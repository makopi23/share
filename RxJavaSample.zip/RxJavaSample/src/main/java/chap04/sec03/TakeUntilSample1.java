package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** takeUntil(stopPredicate)のサンプル */
public class TakeUntilSample1 {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 受け取ったデータが「3」になるまで通知する
            .takeUntil(data -> data == 3);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
  
}
