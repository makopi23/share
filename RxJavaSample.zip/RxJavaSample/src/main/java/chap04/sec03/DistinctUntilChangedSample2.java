package chap04.sec03;

import java.math.BigDecimal;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** distinctUntilChanged(comparer)のサンプル */
public class DistinctUntilChangedSample2 {
  
  public static void main(String[] args) {
    Flowable<String> flowable =
        // Flowableの生成
        Flowable.just("1", "1.0", "0.1", "0.10", "1")
            // 連続して重複したデータを除いて通知する
            .distinctUntilChanged((data1, data2) -> {
              // BigDecimalに変換
              BigDecimal convert1 = new BigDecimal(data1);
              BigDecimal convert2 = new BigDecimal(data2);
              
              // 比較してスケールに関係なく等しいか判定する
              return (convert1.compareTo(convert2) == 0);
            });
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
  }
}
