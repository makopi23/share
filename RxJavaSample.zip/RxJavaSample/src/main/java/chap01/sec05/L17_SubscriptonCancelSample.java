package chap01.sec05;

import java.util.concurrent.TimeUnit;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;

/** リスト17：購読を途中で解除する場合 */
public class L17_SubscriptonCancelSample {
  
  public static void main(String[] args) throws Exception {
    
    // 200ミリ秒ごとに数値を通知するFlowable
    Flowable.interval(200L, TimeUnit.MILLISECONDS)
        .subscribe(new Subscriber<Long>() {
          
          private Subscription subscription;
          private long startTime;
          
          @Override
          public void onSubscribe(Subscription subscription) {
            this.subscription = subscription;
            this.startTime = System.currentTimeMillis();
            this.subscription.request(Long.MAX_VALUE);
          }
          
          @Override
          public void onNext(Long data) {
            // 購読開始から500ミリ秒経っていたら購読を解除し、処理を止める
            if ((System.currentTimeMillis() - startTime) > 500) {
              subscription.cancel();
              System.out.println("購読解除");
              return;
            }
            
            System.out.println("data=" + data);
          }
          
          @Override
          public void onComplete() {
            System.out.println("完了");
          }
          
          @Override
          public void onError(Throwable error) {
            error.printStackTrace();
          }
        });
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
  
}
