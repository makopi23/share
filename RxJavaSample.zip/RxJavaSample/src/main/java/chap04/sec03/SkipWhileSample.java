package chap04.sec03;

import java.util.concurrent.TimeUnit;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** skipWhile(predicate)のサンプル */
public class SkipWhileSample {
  
  public static void main(String[] args) throws Exception {
    Flowable<Long> flowable =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 受け取ったデータが「3」でない間は通知しない
            .skipWhile(data -> data != 3);
    
    // 購読する
    flowable.subscribe(new DebugSubscriber<>());
    
    // しばらく待つ
    Thread.sleep(2000L);
  }
  
}
