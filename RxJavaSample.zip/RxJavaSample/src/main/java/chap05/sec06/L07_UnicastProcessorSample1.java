package chap05.sec06;

import chap04.DebugSubscriber;
import io.reactivex.processors.UnicastProcessor;

/** リスト7：UnicastProcessorのサンプル */
public class L07_UnicastProcessorSample1 {
  
  public static void main(String[] args) throws Exception {
    
    // Processorの生成
    UnicastProcessor<Integer> processor = UnicastProcessor.create();
    
    // データを通知する
    processor.onNext(1);
    processor.onNext(2);
    
    // 途中でSubscriberに購読させる
    System.out.println("Subscriber No.1 追加");
    processor.subscribe(new DebugSubscriber<>("No.1"));
    
    // 別のSubscriberにも購読させる
    System.out.println("Subscriber No.2 追加");
    processor.subscribe(new DebugSubscriber<>("--- No.2"));
    
    // データを通知する
    processor.onNext(3);
    
    // 完了を通知する
    processor.onComplete();
  }
}
