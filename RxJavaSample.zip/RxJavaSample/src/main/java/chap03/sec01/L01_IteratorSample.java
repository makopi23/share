package chap03.sec01;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/** リスト1：Iteratorパターンの使用例 */
public class L01_IteratorSample {
  
  public static void main(String[] args) {
    // ListからIteratorを作成
    List<String> list = Arrays.asList("a", "b", "c");
    Iterator<String> iterator = list.iterator();
    
    // データがある間実行
    while (iterator.hasNext()) {
      // データの取得
      String value = iterator.next();
      // 取得したデータを標準出力
      System.out.println(value);
    }
  }
  
}
