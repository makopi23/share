package chap06.sec03;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import io.reactivex.Flowable;

/** blockingLast()のテスト */
public class BlockingLastTest {
  
  @Test
  public void 最後のデータを取得する() {
    // 取得する結果
    long actual =
        // Flowableの生成
        Flowable.interval(300L, TimeUnit.MILLISECONDS)
            // 3件まで
            .take(3)
            // 最後に通知されるデータをメインスレッド上で取得する
            .blockingLast();
    
    // 確認
    assertThat(actual, is(2L));
  }
}
