package chap01.sec06;

import java.time.DayOfWeek;
import java.time.LocalDate;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;

/** リスト30：Singleのサンプル */
public class L30_SingleSample {
  
  public static void main(String[] args) {
    // Singleの作成
    Single<DayOfWeek> single = Single.create(emitter -> {
      emitter.onSuccess(LocalDate.now().getDayOfWeek());
    });
    
    // 購読する
    single.subscribe(new SingleObserver<DayOfWeek>() {
      
      /** 購読の準備ができた際の処理を行う */
      @Override
      public void onSubscribe(Disposable disposable) {
        // 何もしない
      }
      
      /** データの通知を受け取った際の処理を行う */
      @Override
      public void onSuccess(DayOfWeek value) {
        System.out.println(value);
      }
      
      /** エラーの通知を受け取った際の処理を行う */
      @Override
      public void onError(Throwable e) {
        System.out.println("エラー=" + e);
      }
    });
  }
  
}
