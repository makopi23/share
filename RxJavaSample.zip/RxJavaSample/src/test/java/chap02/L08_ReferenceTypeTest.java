package chap02;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

/** リスト8：final宣言しても状態の変更が可能な例 */
public class L08_ReferenceTypeTest {
  
  @Test
  public void finalを付けても状態が変更可能であることの確認() {
    // finalが付いた参照型の変数
    final ReferenceTypeObject instance = new ReferenceTypeObject();
    
    // 参照先を変更しようとするとコンパイルエラーになる
    // instance = new ReferenceTypeObject();
    
    // 変更前のオブジェクトの状態を確認
    assertThat(instance.getValue(), is("A"));
    
    // instanceの状態を変更することは可能
    instance.setValue("B");
    
    // 状態を変更したオブジェクトの確認
    assertThat(instance.getValue(), is("B"));
  }
  
  /** 参照型のオブジェクト */
  private static class ReferenceTypeObject {
    private String value = "A";
    
    public void setValue(String value) {
      this.value = value;
    }
    
    public String getValue() {
      return value;
    }
  }
  
}
