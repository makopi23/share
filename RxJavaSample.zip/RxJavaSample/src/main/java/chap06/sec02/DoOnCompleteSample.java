package chap06.sec02;

import chap04.DebugSubscriber;
import io.reactivex.Flowable;

/** doOnComplete(onComplete)のサンプル */
public class DoOnCompleteSample {
  
  public static void main(String[] args) throws Exception {
    
    // Flowableの生成
    Flowable.range(1, 5)
        // 完了の通知時のログ
        .doOnComplete(() -> System.out.println("doOnComplete"))
        // 購読する
        .subscribe(new DebugSubscriber<>());
  }
  
}
