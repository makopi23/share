package chap03.sec02;

import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;

/** リスト8：有効になるSchedulerの調査 */
public class L08_SubscribeOnSample {
  
  public static void main(String[] args) throws Exception {
    Flowable.just(1, 2, 3, 4, 5) // FLowableの設定
        .subscribeOn(Schedulers.computation()) // RxComputationThreadPool
        .subscribeOn(Schedulers.io()) // RxCachedThreadScheduler
        .subscribeOn(Schedulers.single()) // RxSingleScheduler
        .subscribe(data -> {
          String threadName = Thread.currentThread().getName();
          System.out.println(threadName + ": " + data);
        });
    
    // しばらく待つ
    Thread.sleep(500);
  }
  
}
