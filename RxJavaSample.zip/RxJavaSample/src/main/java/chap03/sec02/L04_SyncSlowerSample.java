package chap03.sec02;

import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;

/** リスト4：データを受け取る側が重い処理をしている場合 */
public class L04_SyncSlowerSample {
  
  public static void main(String[] args) throws Exception {
    Flowable.interval(1000L, TimeUnit.MILLISECONDS)
        // データ通知時のシステム時間を出力する
        .doOnNext(data -> System.out
            .println("emit: " + System.currentTimeMillis() + ": " + data))
        // 購読する
        .subscribe(data -> Thread.sleep(2000L)); // 重い処理をしていると見なす
    
    // しばらく待つ
    Thread.sleep(5000L);
  }
  
}
